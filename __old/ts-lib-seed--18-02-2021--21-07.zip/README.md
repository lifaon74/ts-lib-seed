#How to use the seed:

1) open init-seed.js
2) edit the `config` object
3) run with node this script
4) removes this instructions from the freshly created folder
