import { helloWorld } from '../core';


export async function debug() {
  helloWorld();
}
